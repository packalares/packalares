"""
Docling wrapper: drop-in for docling-serve's POST /v1/convert/source, but with
smart routing — normal (text-layer) PDFs and Office/CSV go through Docling's
fast CPU pipeline; scanned PDFs and images go through a remote VLM (our Ollama,
reached via the Studio LLM API so it rides the single-GPU queue).

Same request/response shape Studio's docling/client.ts already speaks, so it's
a transparent replacement behind the existing Docling URL.

Env:
  STUDIO_API_URL   OpenAI-compatible chat endpoint (default: in-cluster Studio API)
  VLM_MODEL        vision model id served by Ollama
  STUDIO_API_KEY   Bearer key for the Studio API
  PDF_TEXT_THRESHOLD  avg chars/page below which a PDF is treated as scanned
  VLM_SCALE        page render scale for the VLM (accuracy vs speed)
  VLM_TIMEOUT      per-call timeout (s)
"""
import os, io, base64, time, logging
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

import pypdfium2 as pdfium
from docling.datamodel.base_models import InputFormat, DocumentStream
from docling.datamodel.pipeline_options import (
    PdfPipelineOptions, VlmPipelineOptions, ApiVlmOptions,
)
from docling.datamodel.pipeline_options_vlm_model import ResponseFormat
from docling.document_converter import (
    DocumentConverter, PdfFormatOption, ImageFormatOption,
)
from docling.pipeline.vlm_pipeline import VlmPipeline

log = logging.getLogger("vlm_wrapper")
logging.basicConfig(level=logging.INFO)

STUDIO_API_URL = os.environ.get(
    "STUDIO_API_URL",
    "http://comfyuistudio.user-space-admin:3002/api/llm/v1/chat/completions",
)
VLM_MODEL = os.environ.get("VLM_MODEL", "qwen3-vl:8b-instruct-q8_0")
STUDIO_API_KEY = os.environ.get("STUDIO_API_KEY", "")
PDF_TEXT_THRESHOLD = int(os.environ.get("PDF_TEXT_THRESHOLD", "40"))
VLM_SCALE = float(os.environ.get("VLM_SCALE", "2.0"))
VLM_TIMEOUT = int(os.environ.get("VLM_TIMEOUT", "180"))

IMAGE_EXTS = {"png", "jpg", "jpeg", "tif", "tiff", "bmp", "webp", "gif"}

app = FastAPI()
_cpu = None
_vlm = None


def cpu_converter():
    global _cpu
    if _cpu is None:
        # Text-layer extraction only (no OCR) → fast for digital PDFs; other
        # formats (docx/csv/xlsx/…) use Docling defaults.
        popt = PdfPipelineOptions(do_ocr=False)
        _cpu = DocumentConverter(format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=popt),
        })
    return _cpu


def vlm_converter():
    global _vlm
    if _vlm is None:
        api = ApiVlmOptions(
            url=STUDIO_API_URL,
            headers={"Authorization": f"Bearer {STUDIO_API_KEY}"},
            params={"model": VLM_MODEL},
            prompt=("Transcribe this page to GitHub-flavored Markdown. "
                    "Preserve all text and tables exactly. Output only the Markdown."),
            timeout=VLM_TIMEOUT, scale=VLM_SCALE,
            response_format=ResponseFormat.MARKDOWN,
        )
        opts = VlmPipelineOptions(enable_remote_services=True, vlm_options=api)
        _vlm = DocumentConverter(format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_cls=VlmPipeline, pipeline_options=opts),
            InputFormat.IMAGE: ImageFormatOption(pipeline_cls=VlmPipeline, pipeline_options=opts),
        })
    return _vlm


def pdf_has_text(data: bytes) -> bool:
    """Cheap probe: sample the first few pages' text layer."""
    try:
        pdf = pdfium.PdfDocument(data)
        n = len(pdf)
        sample = min(n, 5)
        total = 0
        for i in range(sample):
            total += len(pdf[i].get_textpage().get_text_range().strip())
        return (total / max(1, sample)) >= PDF_TEXT_THRESHOLD
    except Exception as e:
        log.warning("pdf text probe failed (%s) → treating as scanned", e)
        return False


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/v1/convert/source")
async def convert(req: Request):
    body = await req.json()
    sources = body.get("sources") or []
    if not sources:
        return JSONResponse({"error": "no sources provided"}, status_code=400)
    src = sources[0]
    filename = src.get("filename", "document")
    try:
        data = base64.b64decode(src.get("base64_string", ""))
    except Exception:
        return JSONResponse({"error": "invalid base64_string"}, status_code=400)

    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in IMAGE_EXTS:
        use_vlm = True
    elif ext == "pdf":
        use_vlm = not pdf_has_text(data)
    else:
        use_vlm = False  # docx/csv/xlsx/pptx/md/html/txt → CPU

    conv = vlm_converter() if use_vlm else cpu_converter()
    t0 = time.time()
    try:
        res = conv.convert(source=DocumentStream(name=filename, stream=io.BytesIO(data)))
        md = res.document.export_to_markdown()
    except Exception as e:
        log.exception("convert failed for %s (vlm=%s)", filename, use_vlm)
        return JSONResponse({"error": f"convert failed: {e}"}, status_code=502)
    ms = int((time.time() - t0) * 1000)
    log.info("converted %s pipeline=%s ms=%s chars=%s",
             filename, "vlm" if use_vlm else "cpu", ms, len(md))
    return {
        "document": {"filename": filename, "md_content": md},
        "status": "success",
        "_pipeline": "vlm" if use_vlm else "cpu",
        "_ms": ms,
    }
