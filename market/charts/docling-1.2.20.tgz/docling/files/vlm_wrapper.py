"""
Document Conversion Service — docling ingest + CPU layout + pluggable LLM backend.

Config lives in JSON (config.json, mounted at /config/config.json), NOT chart
values. Secrets are never in config: the API key is read from the env var named
in backend.<mode>.api_key_env (injected from a k8s Secret).

Pipeline:
  ingest (docling) → classify (text vs scanned) → recognize (LLM backend) → format

- Layout detection runs on CPU in-pod (PP-DocLayoutV3), its own /v1/layout endpoint.
- Recognition runs on the LLM backend over OpenAI /v1:
    * backend.mode=external → your Studio/Ollama (GPU queue)
    * backend.mode=local    → in-pod llama-server sidecar (localhost, GPU)
- Recognizer is per-request selectable: dots (end-to-end) | paddle-vl (element crops).
- Field extraction (format=json) routes to the instruction-following extractor.

Endpoints:
  GET  /health
  POST /v1/layout          → CPU layout boxes  {boxes:[{bbox,category,score}]}
  POST /v1/convert         → markdown|html|text|json|csv
  POST /render             → page images as base64 PNG (Studio vision fast-path)
"""
import os, io, re, csv, json, base64, time, logging, statistics
from collections import OrderedDict
from html import escape, unescape
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from starlette.concurrency import run_in_threadpool

import httpx
import pypdfium2 as pdfium
from PIL import Image
from docling.datamodel.base_models import InputFormat, DocumentStream
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.document_converter import DocumentConverter, PdfFormatOption

log = logging.getLogger("conv")
logging.basicConfig(level=logging.INFO)

IMAGE_EXTS = {"png", "jpg", "jpeg", "tif", "tiff", "bmp", "webp", "gif"}
_HERE = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------- config
def load_config():
    for p in (os.environ.get("CONFIG_PATH", "/config/config.json"),
              os.path.join(_HERE, "config.json")):
        try:
            with open(p) as f:
                log.info("loaded config from %s", p)
                return json.load(f)
        except Exception:
            continue
    log.warning("no config.json found; using minimal defaults")
    return {}

CFG = load_config()
DEF = CFG.get("defaults", {})
PROMPTS = CFG.get("prompts", {})
TEXT_THRESHOLD = int(DEF.get("text_threshold", 40))
SCALE = float(DEF.get("render_scale", 2.0))
MAX_PAGES = int(DEF.get("max_vlm_pages", 10))
MAX_DOC_PAGES = int(DEF.get("max_doc_pages", 0))   # text-PDF page guard; 0 = no limit


class DocTooLarge(Exception):
    """Raised when a document exceeds max_doc_pages — a fast, clear 413 instead
    of letting a huge CPU convert run past the client timeout."""

# Pipelines that actually ran a recognizer model (dots/paddle-vl). The CPU
# pipelines (cpu / cpu-geometry / cpu-layout) and the extractor (extract) do
# not, so `_recognizer` is only reported for these.
RECOGNIZER_PIPELINES = {"end-to-end", "element"}


def backend():
    b = CFG.get("backend", {})
    mode = os.environ.get("BACKEND_MODE", b.get("mode", "external"))
    conf = b.get(mode) or b.get("external", {})
    # env overrides let Helm inject the namespaced URL / key without editing JSON
    url = (os.environ.get("LLM_BASE_URL") or conf.get("base_url", "")).rstrip("/")
    key = os.environ.get(conf.get("api_key_env", "STUDIO_API_KEY"), "")
    return url, key, int(conf.get("timeout", 300))


def recognizer_cfg(name):
    r = CFG.get("recognizers", {})
    return r.get(name) or r.get(DEF.get("recognizer", "dots")) or {}


def model_id(cfg):
    """Model name to send the backend. In local mode a recognizer/extractor may
    define `local_model` (the name the in-pod Ollama registers via `ollama
    create`, since it differs from the external hf.co/... id)."""
    mode = os.environ.get("BACKEND_MODE", CFG.get("backend", {}).get("mode", "external"))
    if mode == "local" and cfg.get("local_model"):
        return cfg["local_model"]
    return cfg.get("model")


# ---------------------------------------------------------------- LLM backend (OpenAI /v1)
def llm_chat(model, prompt, image_png=None, options=None):
    url, key, timeout = backend()
    content = [{"type": "text", "text": prompt}]
    # image_png may be a single PNG (bytes) or a list of pages (multi-page docs).
    imgs = image_png if isinstance(image_png, (list, tuple)) else ([] if image_png is None else [image_png])
    for im in imgs:
        b64 = base64.b64encode(im).decode()
        content.append({"type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{b64}"}})
    opts = dict(options or {})
    payload = {"model": model, "stream": False,
               "messages": [{"role": "user", "content": content}],
               "temperature": opts.get("temperature", 0)}
    if "num_predict" in opts:
        payload["max_tokens"] = opts["num_predict"]
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    r = httpx.post(f"{url}/chat/completions", json=payload, headers=headers, timeout=timeout)
    r.raise_for_status()
    return (r.json()["choices"][0]["message"]["content"] or "")


def _strip_fence(s):
    s = (s or "").strip()
    if s.startswith("```"):
        parts = s.split("```")
        if len(parts) >= 3:
            s = parts[1]
            if "\n" in s:
                s = s.split("\n", 1)[1]
        s = s.strip()
    return s


# ---------------------------------------------------------------- docling CPU (text PDFs / Office)
_cpu = None
def cpu_converter():
    global _cpu
    if _cpu is None:
        popt = PdfPipelineOptions(do_ocr=False)
        _cpu = DocumentConverter(format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=popt)})
    return _cpu


def _stream(filename, data):
    return DocumentStream(name=filename, stream=io.BytesIO(data))


def cpu_convert(filename, data):
    """Run the CPU docling pipeline once. Callers reuse the result across
    formats (markdown/html/text/csv) — never convert twice."""
    return cpu_converter().convert(source=_stream(filename, data))


def pdf_page_count(data):
    try:
        return len(pdfium.PdfDocument(data))
    except Exception:
        return 0


def pdf_has_text(data):
    try:
        pdf = pdfium.PdfDocument(data)
        n = min(len(pdf), 5)
        total = sum(len(pdf[i].get_textpage().get_text_range().strip()) for i in range(n))
        return (total / max(1, n)) >= TEXT_THRESHOLD
    except Exception as e:
        log.warning("pdf text probe failed (%s) → scanned", e)
        return False


# ---------------------------------------------------------------- rendering
def page_pngs(data, scale=None, limit=None):
    scale = scale or SCALE
    pdf = pdfium.PdfDocument(data)
    n = len(pdf)
    out = []
    for i in range(n if limit is None else min(n, limit)):
        pil = pdf[i].render(scale=scale).to_pil().convert("RGB")
        buf = io.BytesIO(); pil.save(buf, "PNG")
        out.append(buf.getvalue())
    return out, n


def image_png(data):
    pil = Image.open(io.BytesIO(data)).convert("RGB")
    buf = io.BytesIO(); pil.save(buf, "PNG")
    return buf.getvalue()


# ---------------------------------------------------------------- CPU layout (PP-DocLayoutV3)
_layout = None
def layout_model():
    global _layout
    if _layout is None:
        os.environ.setdefault("PADDLE_PDX_MODEL_SOURCE", "huggingface")
        from paddleocr import LayoutDetection
        _layout = LayoutDetection(model_name=CFG.get("layout", {}).get("model_name", "PP-DocLayoutV3"))
    return _layout


def detect_layout(png):
    import numpy as np
    th = float(CFG.get("layout", {}).get("threshold", 0.3))
    pil = Image.open(io.BytesIO(png)).convert("RGB")
    res = list(layout_model().predict(np.array(pil), batch_size=1, threshold=th))
    boxes = res[0]["boxes"] if res else []
    out = []
    for b in boxes:
        c = b.get("coordinate") or b.get("bbox")
        out.append({"bbox": [int(v) for v in c], "category": b.get("label", ""),
                    "score": round(float(b.get("score", 0)), 3)})
    out.sort(key=lambda e: (round(e["bbox"][1] / 40), e["bbox"][0]))
    return out


# ---------------------------------------------------------------- OTSL helpers (PaddleOCR-VL tables)
def otsl_to_rows(otsl):
    rows = []
    for row in otsl.split("<nl>"):
        if not row.strip():
            continue
        cells = [m.group(1).strip() if m.group(0).startswith("<fcel>") else ""
                 for m in re.finditer(r"<fcel>([^<]*)|<ecel>", row)]
        if cells:
            rows.append(cells)
    return rows


def rows_to_html(rows):
    return "<table>" + "".join(
        "<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows) + "</table>"


def rows_to_csv(rows):
    """Rectangular CSV: every row padded to the widest row's column count, with
    a plain "\\n" line terminator (not the csv module's default CRLF)."""
    width = max((len(r) for r in rows), default=0)
    buf = io.StringIO(); w = csv.writer(buf, lineterminator="\n")
    for r in rows:
        w.writerow(list(r) + [""] * (width - len(r)))
    return buf.getvalue()


CSV_GAP = "\n\n\n"   # ~3 empty rows between tables and before the non-table text


def build_csv(tables, nontab):
    """Assemble the csv payload: each table (rectangular) separated by blank
    rows, then the unique non-table text section (if any)."""
    body = CSV_GAP.join(rows_to_csv(t) for t in tables if t)
    if nontab:
        body = (body + CSV_GAP if body else "") + "# ---- non-table text ----\n" + "\n".join(nontab)
    return body


def strip_tables_text(html):
    """The text OUTSIDE any <table> in an HTML/markdown blob — unique lines in
    order. Used to recover a scanned page's non-table text (headers, IBANs, …)
    from the recognizer's end-to-end output."""
    t = re.sub(r"<table[^>]*>.*?</table>", "\n", html or "", flags=re.S | re.I)
    t = unescape(re.sub(r"<[^>]+>", " ", t))
    out, seen = [], set()
    for ln in t.splitlines():
        s = ln.strip()
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def drop_index_rows(rows):
    """Drop column-numbering rows — a non-header row whose every non-empty cell
    is a 1-2 digit integer (e.g. the '1 2 3 4 5' row under an invoice header).
    Safe: real data rows carry text/amounts, not only bare small integers."""
    out = []
    for i, r in enumerate(rows):
        vals = [c.strip() for c in r if c.strip()]
        if i > 0 and len(vals) >= 2 and all(re.fullmatch(r"\d{1,2}", v) for v in vals):
            continue
        out.append(r)
    return out


def merge_by_header(tables):
    """Merge tables that share the same header row into one (header kept once) —
    the scanned-path equivalent of what text_pdf_tables does for text PDFs, so a
    table repeated across pages folds into one. Different headers stay separate."""
    groups = OrderedDict()
    for t in tables:
        if not t:
            continue
        header = tuple(t[0])
        groups.setdefault(header, []).append(t[1:])
    out = []
    for header, bodies in groups.items():
        rows = [list(header)]
        for body in bodies:
            rows.extend(body)
        out.append(rows)
    return out


def html_tables_to_rows(html):
    """Parse every <table> in an HTML string into a list of row-lists. dots
    emits tables as HTML in its end-to-end output, so this turns that into the
    same rows shape the OTSL path produces (rowspan/colspan text is kept,
    span geometry is not — good enough for CSV)."""
    tables = []
    for tbl in re.findall(r"<table[^>]*>(.*?)</table>", html or "", re.S | re.I):
        rows = []
        for tr in re.findall(r"<tr[^>]*>(.*?)</tr>", tbl, re.S | re.I):
            cells = [unescape(re.sub(r"<[^>]+>", " ", c)).strip()
                     for c in re.findall(r"<t[hd][^>]*>(.*?)</t[hd]>", tr, re.S | re.I)]
            if cells:
                rows.append(cells)
        if rows:
            tables.append(rows)
    return tables


# ---------------------------------------------------------------- text-PDF tables → CSV (docling geometry, no LLM)
def _center(r):
    xs = [r.r_x0, r.r_x1, r.r_x2, r.r_x3]; ys = [r.r_y0, r.r_y1, r.r_y2, r.r_y3]
    return (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, (max(ys) - min(ys))


def _cell_lines(tcell, pcs, tol):
    """Rebuild a cell's physical lines from page word centers (docling flattens
    wrapped lines to spaces; geometry recovers them)."""
    bb = tcell.bbox
    inside = [(cy, cx, c) for cx, cy, c in pcs
              if bb.l - 0.5 <= cx <= bb.r + 0.5 and bb.t - 0.5 <= cy <= bb.b + 0.5]
    inside.sort()
    lines, prev = [], None
    for cy, cx, txt in inside:
        if prev is None or cy - prev > tol:
            lines.append([])
        lines[-1].append((cx, txt)); prev = cy
    out = [" ".join(t for _, t in sorted(l)).strip() for l in lines]
    if out:
        return out
    return [(tcell.text or "").strip()] if (tcell.text or "").strip() else [""]


def text_pdf_tables(res):
    """Deterministic table extraction from an already-converted docling result:
    merge same-header tables (multi-page) + explode multi-line cells. Returns
    list[rows]. Takes `res` so the caller's single convert is reused."""
    doc = res.document
    groups = OrderedDict()
    for t in doc.tables:
        td = t.data
        nr, nc = td.num_rows, td.num_cols
        pno = (t.prov[0].page_no - 1) if t.prov else 0
        page = res.pages[pno] if 0 <= pno < len(res.pages) else res.pages[0]
        pcs, heights = [], []
        for c in page.cells:
            if (c.text or "").strip():
                cx, cy, h = _center(c.rect)
                pcs.append((cx, cy, c.text)); heights.append(h)
        tol = 0.6 * statistics.median(heights) if heights else 4.0
        grid = [[[""] for _ in range(nc)] for _ in range(nr)]
        for tc in td.table_cells:
            r, cc = tc.start_row_offset_idx, tc.start_col_offset_idx
            if 0 <= r < nr and 0 <= cc < nc:
                grid[r][cc] = _cell_lines(tc, pcs, tol)
        header = tuple(" ".join(cell).strip() for cell in grid[0]) if nr else ()
        groups.setdefault(header, []).append(grid[1:])
    tables = []
    for header, row_lists in groups.items():
        rows = [list(header)]
        for rowset in row_lists:
            for row in rowset:
                depth = max((len(cell) for cell in row), default=1)
                for k in range(depth):
                    rows.append([(cell[k] if k < len(cell) else "") for cell in row])
        tables.append(rows)
    return tables


def doc_nontable_text(doc):
    """Unique non-table text items (section titles, paragraphs, IBANs, etc.) in
    reading order — the content that lives outside tables. Mirrors the original
    docling_test.py '# non-table text' section."""
    seen, out = set(), []
    for ti in getattr(doc, "texts", []) or []:
        s = (getattr(ti, "text", "") or "").strip()
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def office_tables(doc):
    """Rows for each table in an Office doc (docx/xlsx/pptx). Office has no page
    geometry, so we use each table's own docling HTML export instead of the
    PDF-cell geometry path."""
    tables = []
    for t in getattr(doc, "tables", []) or []:
        try:
            tables += html_tables_to_rows(t.export_to_html(doc=doc))
        except Exception:
            pass
    return tables


def docling_layout_json(res, table_html=False):
    """CPU layout dump from an already-converted docling result (no model):
    every element as {bbox (top-left px), category, text, page}. With
    table_html=True, table elements also carry an `html` grid (their cells) —
    used by the positioned-HTML renderer since a table's own `.text` is empty."""
    doc = res.document
    try:
        heights = {pno: p.size.height for pno, p in (doc.pages or {}).items()}
    except Exception:
        heights = {}
    out = []
    for item, _level in doc.iterate_items():
        prov = getattr(item, "prov", None)
        if not prov:
            continue
        p = prov[0]
        bb = p.bbox
        h = heights.get(p.page_no)
        try:
            bb = bb.to_top_left_origin(page_height=h) if h else bb
        except Exception:
            pass
        label = str(getattr(item, "label", "") or "")
        el = {"bbox": [round(bb.l), round(bb.t), round(bb.r), round(bb.b)],
              "category": label, "text": getattr(item, "text", "") or "", "page": p.page_no}
        if table_html and "table" in label.lower() and hasattr(item, "export_to_html"):
            try:
                el["html"] = item.export_to_html(doc=doc)
            except Exception:
                pass
        out.append(el)
    return out


def _docling_page_sizes(res):
    """Page dimensions (width, height) in docling's coordinate space, keyed by
    page_no — the canvas for positioned HTML."""
    try:
        return {pno: (p.size.width, p.size.height) for pno, p in (res.document.pages or {}).items()}
    except Exception:
        return {}


def positioned_html(elements, sizes, scale=1.0):
    """Render layout elements as absolutely-positioned boxes, one canvas per
    page — the HTML mirrors the original page geometry. `elements` is the
    layout-json list ({bbox, category, text, page, html?}); `sizes` maps
    page_no -> (width, height) in the SAME coordinate space as the bboxes.
    `scale` enlarges everything uniformly (points render small, so text PDFs
    use ~1.5). Tables carrying an `html` grid render that grid in place."""
    by_page = OrderedDict()
    for el in elements:
        bb = el.get("bbox")
        if isinstance(bb, (list, tuple)) and len(bb) == 4:
            by_page.setdefault(el.get("page", 1), []).append(el)
    parts = [
        '<!DOCTYPE html><html><head><meta charset="utf-8">',
        "<style>",
        "body{margin:0;background:#525659}",
        ".page{position:relative;margin:20px auto;background:#fff;"
        "box-shadow:0 2px 10px rgba(0,0,0,.5)}",
        ".el{position:absolute;box-sizing:border-box;"
        "font-family:'Helvetica Neue',Arial,sans-serif;line-height:1.12}",
        # text boxes: fix left/top/width, let height grow so nothing is clipped
        ".txt{white-space:pre-wrap;word-break:break-word;overflow:visible}",
        # table boxes: keep the geometry, the grid fills it
        ".tbl{overflow:hidden}",
        ".tbl table{width:100%;height:100%;border-collapse:collapse;font-size:10px}",
        ".tbl td,.tbl th{border:1px solid #bbb;padding:1px 3px;vertical-align:top;"
        "text-align:left}",
        ".tbl th{background:#f2f2f2;font-weight:600}",
        "</style></head><body>",
    ]
    for pno in sorted(by_page):
        w, h = sizes.get(pno, (0, 0))
        parts.append('<div class="page" style="width:%dpx;height:%dpx">'
                     % (round(w * scale), round(h * scale)))
        for el in by_page[pno]:
            l, t, r, b = el["bbox"]
            x, y = round(l * scale), round(t * scale)
            bw, bh = round(max(0, r - l) * scale), round(max(0, b - t) * scale)
            if el.get("html"):                       # a table grid — fixed box
                parts.append('<div class="el tbl" style="left:%dpx;top:%dpx;width:%dpx;height:%dpx">%s</div>'
                             % (x, y, bw, bh, el["html"]))
            else:
                # Font from a per-LINE height, not the whole box: a tall box is a
                # multi-line block, so dividing by its line count keeps text sane
                # (this is what caused "too big"). Height is left to grow so text
                # is never clipped ("hidden").
                txt = el.get("text", "") or ""
                lines = max(1, txt.count("\n") + 1)
                line_h = (b - t) / lines * scale
                fs = max(7, min(15, round(line_h * 0.78)))
                parts.append('<div class="el txt" style="left:%dpx;top:%dpx;width:%dpx;font-size:%dpx">%s</div>'
                             % (x, y, bw, fs, escape(txt)))
        parts.append("</div>")
    parts.append("</body></html>")
    return "".join(parts)


# ---------------------------------------------------------------- JSON parsing
def _parse_extract_json(raw):
    """Tolerant parser for extractor output: strip code fences, isolate the JSON
    object, drop trailing commas, and quote RO comma-decimals (e.g. 53,48) that
    OCR models emit as bare, invalid numbers."""
    raw = _strip_fence(raw)
    a, b = raw.find("{"), raw.rfind("}")
    cand = raw[a:b + 1] if 0 <= a < b else raw
    cand = re.sub(r",\s*([}\]])", r"\1", cand)
    cand = re.sub(r':\s*(-?\d+),(\d+)\s*([,}\]])', r': "\1,\2"\3', cand)
    try:
        return {"content": json.loads(cand), "pipeline": "extract"}
    except Exception:
        return {"content": raw, "pipeline": "extract", "warning": "unparseable json"}


# ---------------------------------------------------------------- recognition
def recognize_page_endtoend(png, model, opts, prompt):
    """dots-style: whole page → markdown/html in one call."""
    return _strip_fence(llm_chat(model, prompt, png, opts))


def recognize_page_regions(png, model, opts):
    """CPU layout → per-region crop → OCR (text) or table recognition (OTSL).
    Returns a list of region dicts for one page: {bbox, category} plus `text`
    (OCR) or `rows`/`otsl` (tables); picture regions carry only their box.
    The shared core for element-mode markdown/html/csv and positioned HTML."""
    pil = Image.open(io.BytesIO(png)).convert("RGB")
    out = []
    for reg in detect_layout(png):
        cat = reg["category"].lower()
        item = {"bbox": reg["bbox"], "category": reg["category"]}
        if cat in ("image", "picture"):
            out.append(item)
            continue
        x0, y0, x1, y1 = reg["bbox"]
        buf = io.BytesIO(); pil.crop((x0, y0, x1, y1)).save(buf, "PNG"); cpng = buf.getvalue()
        if "table" in cat:
            otsl = llm_chat(model, PROMPTS.get("table", "Table Recognition:"), cpng, opts)
            item["rows"] = otsl_to_rows(otsl) if "<fcel>" in otsl else []
            item["otsl"] = otsl
        else:
            item["text"] = llm_chat(model, PROMPTS.get("ocr_text", "OCR:"), cpng, opts).strip()
        out.append(item)
    return out


def recognize_page_element(png, model, opts, want):
    """Assemble a page from its regions: flowing markdown/html, or the table
    list for csv/tables. want in {'markdown','html','csv','tables'}."""
    regs = recognize_page_regions(png, model, opts)
    if want in ("csv", "tables"):
        return {"tables": [r["rows"] for r in regs if "rows" in r]}
    parts = []
    for r in regs:
        if "rows" in r:
            parts.append(rows_to_html(r["rows"]) if r["rows"] else "<pre>" + r.get("otsl", "") + "</pre>")
        elif "text" in r:
            parts.append(("<p>" + r["text"].replace("\n", "<br>") + "</p>") if want == "html" else r["text"])
    return {"content": "\n\n".join(p for p in parts if p)}


def extract_json(source, schema):
    """Field extraction via the extractor model. `source` is markdown text (text
    docs — sent as text: cheaper and more accurate) or a list of page PNGs
    (scans — all pages in one call)."""
    ex = CFG.get("extractor", {})
    prompt = PROMPTS.get("extract_json", "Extract as JSON. Output only JSON.")
    if schema:
        prompt += "\nJSON schema:\n" + json.dumps(schema)
    if isinstance(source, str):
        prompt += "\n\nDOCUMENT:\n" + source
        source = None
    raw = llm_chat(model_id(ex), prompt, source, ex.get("options", {}))
    return _parse_extract_json(raw)


def scanned_html_layout(pngs, model, opts):
    """Positioned HTML for scanned pages: CPU layout → per-region OCR/table,
    each placed at its bbox (in the rendered PNG's pixel space, so the page
    canvas is that PNG's size). Works with any recognizer — the layout is
    deterministic on CPU, the recognizer only OCRs each crop."""
    els, sizes = [], {}
    for i, png in enumerate(pngs, 1):
        sizes[i] = Image.open(io.BytesIO(png)).size
        for r in recognize_page_regions(png, model, opts):
            el = {"bbox": r["bbox"], "category": r["category"], "page": i}
            if r.get("rows"):
                el["html"] = rows_to_html(r["rows"])
            elif "rows" in r:                       # table region, OTSL didn't parse
                el["text"] = r.get("otsl", "")      # keep the raw content, don't drop it
            else:
                el["text"] = r.get("text", "")
            els.append(el)
    return {"content": positioned_html(els, sizes), "pipeline": "element"}


def transcribe_pages(pngs, fmt, rc, model, opts):
    """markdown/html/text transcription of rendered pages via the recognizer."""
    prompt = PROMPTS.get("transcribe_html" if fmt == "html" else "transcribe_md",
                         PROMPTS.get("transcribe_page", "Transcribe to Markdown."))
    element = rc.get("mode", "end-to-end") == "element"
    want = "markdown" if fmt == "text" else fmt
    outs = []
    for png in pngs:
        if element:
            outs.append(recognize_page_element(png, model, opts, want)["content"])
        else:
            outs.append(recognize_page_endtoend(png, model, opts, prompt))
    content = "\n\n".join(o for o in outs if o)
    if fmt == "text":
        content = re.sub(r"<[^>]+>", " ", content)
    return {"content": content, "pipeline": "element" if element else "end-to-end"}


def scanned_tables(pngs, rc, model, opts):
    """csv for scanned pages, per recognizer:
      • dots (end-to-end): ONE call/page → parse the HTML tables it emits.
      • paddle-vl (element): CPU layout → per-region OTSL → rows."""
    element = rc.get("mode") == "element"
    prompt = PROMPTS.get("transcribe_md", PROMPTS.get("transcribe_page", "Transcribe to Markdown."))
    tables, nontab, seen = [], [], set()

    def add_nontext(s):
        s = (s or "").strip()
        if s and s not in seen:
            seen.add(s); nontab.append(s)

    for png in pngs:
        if element:
            for r in recognize_page_regions(png, model, opts):
                if r.get("rows"):
                    tables.append(r["rows"])
                elif r.get("text"):
                    add_nontext(r["text"])
        else:
            out = recognize_page_endtoend(png, model, opts, prompt)
            tables += html_tables_to_rows(out)
            for s in strip_tables_text(out):
                add_nontext(s)
    tables = merge_by_header([drop_index_rows(t) for t in tables])
    pipeline = "element" if element else "end-to-end"
    return {"content": build_csv(tables, nontab), "pipeline": pipeline}


# ---------------------------------------------------------------- format dispatch
def convert_one(filename, data, fmt, recognizer, schema, options):
    """Dispatch one document to the right pipeline.

    Two branches:
      • text PDF / Office  → docling on CPU (one convert, reused for every format)
      • scanned PDF / image → render pages, run the vision backend (external/local)
    """
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    is_image = ext in IMAGE_EXTS
    is_pdf = ext == "pdf"
    scanned_pdf = is_pdf and not pdf_has_text(data)
    # Guard the unbounded text-PDF path: a huge CPU convert would otherwise run
    # past the client timeout. Scanned PDFs are already page-capped at render.
    if is_pdf and not scanned_pdf and MAX_DOC_PAGES:
        n = pdf_page_count(data)
        if n > MAX_DOC_PAGES:
            raise DocTooLarge(
                f"document has {n} pages, exceeds max_doc_pages={MAX_DOC_PAGES}; "
                "split it or raise the limit in config.json")
    rc = recognizer_cfg(recognizer)
    model = model_id(rc)
    opts = {**rc.get("options", {}), **(options or {})}

    # ---- text documents: docling CPU, a SINGLE convert reused across formats ----
    if not is_image and not scanned_pdf:
        res = cpu_convert(filename, data)
        doc = res.document
        if fmt == "markdown":
            return {"content": doc.export_to_markdown(), "pipeline": "cpu"}
        if fmt == "html":
            # positioned HTML: elements placed at their bbox — mirrors the page.
            # scale 1.5 (points render small); tables carry their real grid.
            return {"content": positioned_html(docling_layout_json(res, table_html=True),
                                               _docling_page_sizes(res), scale=1.5),
                    "pipeline": "cpu-layout"}
        if fmt == "text":
            return {"content": doc.export_to_text(), "pipeline": "cpu"}
        if fmt == "csv":
            # PDF: cell geometry (multi-line explode, cross-page merge).
            # Office (docx/xlsx/pptx): no page geometry → each table's HTML export.
            if is_pdf:
                tabs = text_pdf_tables(res); pipe = "cpu-geometry"
            else:
                tabs = office_tables(doc); pipe = "cpu"
            return {"content": build_csv(tabs, doc_nontable_text(doc)), "pipeline": pipe}
        if fmt == "json":
            return extract_json(doc.export_to_markdown(), schema)   # text → extractor, no render
        return {"content": doc.export_to_markdown(), "pipeline": "cpu"}  # safety net

    # ---- scanned PDF / image: render pages, run the vision backend ----
    pngs = [image_png(data)] if is_image else page_pngs(data, limit=MAX_PAGES)[0]
    if fmt == "json":
        return extract_json(pngs, schema)
    if fmt == "csv":
        return scanned_tables(pngs, rc, model, opts)
    if fmt == "html":
        return scanned_html_layout(pngs, model, opts)   # positioned, mirrors the scan
    return transcribe_pages(pngs, fmt, rc, model, opts)


# ---------------------------------------------------------------- app
app = FastAPI()


_models_cache = {"t": 0.0, "data": None}
def check_models():
    """Are the configured recognizer/extractor models present on the LLM backend?
    Queries the backend's /v1/models. Cached 5 min + short timeout so /health
    (the liveness probe) never blocks. Returns {backend_reachable, present, missing}."""
    now = time.time()
    c = _models_cache
    if c["data"] is not None and now - c["t"] < 300:
        return c["data"]
    want = {}
    for name, rc in CFG.get("recognizers", {}).items():
        if rc.get("model"):
            want[name] = rc["model"]
    ex = CFG.get("extractor", {}).get("model")
    if ex:
        want["extractor"] = ex
    out = {"backend_reachable": False, "present": {}, "missing": []}
    url, key, _ = backend()
    try:
        headers = {"Authorization": f"Bearer {key}"} if key else {}
        r = httpx.get(f"{url}/models", headers=headers, timeout=4.0)
        r.raise_for_status()
        ids = [m.get("id", "") for m in r.json().get("data", [])]
        out["backend_reachable"] = True
        for role, mid in want.items():
            present = mid in ids or any(mid.split(":")[0] in i for i in ids)
            out["present"][role] = present
            if not present:
                out["missing"].append(mid)
    except Exception as e:
        out["error"] = str(e)[:150]
    c["t"], c["data"] = now, out
    return out


@app.get("/health")
def health():
    url, _, _ = backend()
    return {"status": "ok", "backend": url, "formats": CFG.get("formats", []),
            "models": check_models()}


def _decode(body, key="base64_string"):
    """Decode a base64 field; returns bytes or raises ValueError."""
    try:
        return base64.b64decode(body.get(key) or "")
    except Exception as e:
        raise ValueError("invalid base64_string") from e


def _first_page_png(fn, data):
    ext = fn.rsplit(".", 1)[-1].lower() if "." in fn else ""
    return image_png(data) if ext in IMAGE_EXTS else page_pngs(data, limit=1)[0][0]


@app.post("/v1/layout")
async def v1_layout(req: Request):
    body = await req.json()
    try:
        data = _decode(body)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    fn = body.get("filename", "document")
    t0 = time.perf_counter()
    try:
        boxes = await run_in_threadpool(lambda: detect_layout(_first_page_png(fn, data)))
    except Exception as e:
        log.exception("layout failed")
        return JSONResponse({"error": f"layout failed: {e}"}, status_code=502)
    return {"boxes": boxes, "_ms": round((time.perf_counter() - t0) * 1000)}


@app.post("/v1/convert")
async def v1_convert(req: Request):
    body = await req.json()
    srcs = body.get("sources") or []
    if not srcs:
        return JSONResponse({"error": "no sources provided"}, status_code=400)
    src = srcs[0]
    fn = src.get("filename", "document")
    try:
        data = _decode(src)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    fmt = body.get("format", DEF.get("format", "markdown"))
    recognizer = body.get("recognizer", DEF.get("recognizer", "dots"))
    if fmt not in CFG.get("formats", ["markdown"]):
        return JSONResponse({"error": f"unsupported format {fmt}"}, status_code=400)
    t0 = time.perf_counter()
    try:
        r = await run_in_threadpool(convert_one, fn, data, fmt, recognizer,
                                    body.get("schema"), body.get("options") or {})
    except DocTooLarge as e:
        return JSONResponse({"error": str(e)}, status_code=413)
    except httpx.HTTPStatusError as e:
        return JSONResponse({"error": f"llm upstream {e.response.status_code}: {e.response.text[:200]}"},
                            status_code=502)
    except Exception as e:
        log.exception("convert failed for %s", fn)
        return JSONResponse({"error": f"convert failed: {e}"}, status_code=502)
    resp = {"document": {"filename": fn, "format": fmt, "content": r.get("content")},
            "status": "success", "_pipeline": r.get("pipeline"),
            "_ms": round((time.perf_counter() - t0) * 1000)}
    if r.get("pipeline") in RECOGNIZER_PIPELINES:
        resp["_recognizer"] = recognizer   # only when a recognizer actually ran
    if r.get("warning"):
        resp["warning"] = r["warning"]
    return resp


def _render(fn, data, mx):
    ext = fn.rsplit(".", 1)[-1].lower() if "." in fn else ""
    if ext in IMAGE_EXTS:
        return {"kind": "image", "scanned": True, "page_count": 1,
                "images": [base64.b64encode(image_png(data)).decode()]}
    if ext == "pdf":
        scanned = not pdf_has_text(data)
        pngs, n = page_pngs(data, limit=mx) if scanned else ([], len(pdfium.PdfDocument(data)))
        imgs = [base64.b64encode(p).decode() for p in pngs] if (scanned and n <= mx) else []
        return {"kind": "pdf", "scanned": scanned, "page_count": n, "images": imgs}
    return {"kind": "other", "scanned": False, "page_count": 0, "images": []}


@app.post("/render")
async def render(req: Request):
    """Return page images as base64 PNG for scanned docs (Studio vision fast-path)."""
    body = await req.json()
    fn = body.get("filename", "document")
    try:
        mx = int(body.get("max_pages", MAX_PAGES))
    except Exception:
        mx = MAX_PAGES
    try:
        data = _decode(body)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    return await run_in_threadpool(_render, fn, data, mx)
