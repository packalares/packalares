{{/*
Helpers for the LocalMaps chart.

Rule: every name and label is derived from `.Values.appName` +
`.Release.Name`. Rulebook #5 (name prefix) + #6 (instance label).
*/}}

{{/*
Fully-qualified resource name. Prefer an explicit `appName`; fall back
to the chart name if unset (e.g. bare `helm template`).
*/}}
{{- define "localmaps.fullname" -}}
{{- default .Chart.Name .Values.appName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "localmaps.name" -}}
{{- default .Chart.Name .Values.appName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Canonical service name: `{appName}-svc` per docs/10-deploy.md.
Used by the entrance auto-host resolver.
*/}}
{{- define "localmaps.serviceName" -}}
{{- printf "%s-svc" (include "localmaps.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels applied to every resource.

`app.kubernetes.io/instance` is MANDATORY per rulebook #6 — the
Start/Stop controller queries by it.
*/}}
{{- define "localmaps.labels" -}}
app.kubernetes.io/name: {{ include "localmaps.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "localmaps.name" . }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{/*
Selector labels — the subset of labels that MUST be stable across
upgrades; used by Deployment `selector.matchLabels`.
*/}}
{{- define "localmaps.selectorLabels" -}}
app: {{ include "localmaps.name" . }}
app.kubernetes.io/name: {{ include "localmaps.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Data hostPath on the node. Shared across every container in the pod.
Matches docs/10-deploy.md.
*/}}
{{- define "localmaps.dataHostPath" -}}
{{- printf "%s/%s" .Values.userspace.appData (include "localmaps.name" .) -}}
{{- end -}}

{{/*
ServiceAccount name. Rulebook: keep it app-scoped.
*/}}
{{- define "localmaps.serviceAccountName" -}}
{{- printf "%s-sa" (include "localmaps.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
