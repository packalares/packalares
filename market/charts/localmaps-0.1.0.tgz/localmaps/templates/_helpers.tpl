{{- define "localmaps.fullname" -}}
{{- default .Chart.Name .Values.appName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "localmaps.name" -}}
{{- default .Chart.Name .Values.appName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "localmaps.serviceName" -}}
{{- printf "%s-svc" (include "localmaps.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "localmaps.serviceAccountName" -}}
{{- printf "%s-sa" (include "localmaps.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "localmaps.dataHostPath" -}}
{{- printf "%s/%s" .Values.userspace.appData (include "localmaps.name" .) -}}
{{- end -}}

{{- define "localmaps.labels" -}}
app.kubernetes.io/name: {{ include "localmaps.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: {{ include "localmaps.name" . }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end -}}

{{- define "localmaps.selectorLabels" -}}
app: {{ include "localmaps.name" . }}
app.kubernetes.io/name: {{ include "localmaps.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
