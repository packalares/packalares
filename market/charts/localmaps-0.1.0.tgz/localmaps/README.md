# LocalMaps Helm chart

Single-pod chart that ships the full LocalMaps stack (gateway + worker
+ redis + protomaps + valhalla + pelias-es + pelias-api) for the
Packalares market. See `../../docs/10-deploy.md` for the design
rationale.

## Files

| Path | Purpose |
|---|---|
| `Chart.yaml` | Chart metadata (name, version, appVersion) |
| `OlaresManifest.yaml` | Packalares market manifest (name, icon, entrances, description) — read by the installer |
| `values.yaml` | Default values (images, resources, DNS, service port) |
| `values.schema.json` | JSON schema for values.yaml |
| `templates/_helpers.tpl` | Name + label helpers |
| `templates/deployment.yaml` | One Deployment, one Pod, seven containers |
| `templates/service.yaml` | `{appName}-svc:8080` — the single ingress target |
| `templates/configmap.yaml` | Shared env + Pelias config |
| `templates/serviceaccount.yaml` | App-scoped ServiceAccount |
| `templates/NOTES.txt` | Post-install hints |

## Conventions applied

- Rule 5 — every resource name prefixed with `{{ .Values.appName }}`.
- Rule 6 — every pod template carries `app.kubernetes.io/instance: {{ .Release.Name }}`.
- Rule 7 — DNS resolver pinned to `kube-dns.kube-system.svc.cluster.local`.
- No `runtimeClassName: nvidia` (CPU-only stack).
- Service named `{{ .Values.appName }}-svc` so the Olares entrance
  auto-host resolver finds it.
- HostPath `/packalares/Apps/appdata/localmaps` (via
  `{{ .Values.userspace.appData }}/{{ .Values.appName }}`) →
  mounted as `/data` in every container with subPaths.
- Images pinned by semver tag; each has a `# TODO: pin SHA before prod`
  comment per `docs/08-security.md`.
- Two entrances: `localmaps` (public) and `localmaps-admin` (internal).
  The gateway enforces auth on `/admin` routes via `X-BFL-User`.

## Why single pod?

1. Every service reads from the same `/data` tree (regions + tiles +
   routing data + pelias index).
2. Localhost between sidecars is cheaper than cross-service hops.
3. Fits the rulebook convention for Packalares apps.

## Why no nginx front?

The Go gateway serves both the UI static bundle and the API on port
8080, including `/api/ws` WebSockets. docs/10-deploy.md explicitly
says "no nginx front (gateway serves directly)".

## Local rendering

```sh
helm lint deploy/chart
helm template localmaps deploy/chart > /tmp/rendered.yaml
```

## Override points

- `images.*.tag` — pin new versions once they've been CI-built.
- `resources.peliasEs.requests.memory` + `elasticsearch.javaOpts` —
  grow together as more regions are installed.
- `logLevel` — `debug` for triage; `info` default.
