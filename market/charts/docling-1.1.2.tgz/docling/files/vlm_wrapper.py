"""
Docling wrapper: drop-in for docling-serve's POST /v1/convert/source, with
smart routing —
  • text-layer PDFs + Office/CSV → Docling's fast CPU pipeline;
  • scanned PDFs + images        → a vision model (Ollama) called directly via
                                    the Studio LLM API, so it runs on the GPU
                                    through Studio's single-GPU queue.

For the VLM path we render pages ourselves (pypdfium2) and POST them to the
Studio OpenAI-compatible endpoint, returning the model's Markdown as-is. We do
NOT use docling's VlmPipeline: its markdown→document reassembly
(`_turn_md_into_doc`) is fragile and raises "Can not append a child with
children" on many real pages. Since we only need Markdown and the model already
returns Markdown, the round-trip through docling's doc tree is skipped.

Same request/response shape Studio's docling/client.ts speaks.

Env: STUDIO_API_URL, VLM_MODEL, STUDIO_API_KEY, PDF_TEXT_THRESHOLD, VLM_SCALE,
     VLM_TIMEOUT, VLM_PROMPT
"""
import os, io, base64, time, logging
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

import httpx
import pypdfium2 as pdfium
from PIL import Image
from docling.datamodel.base_models import InputFormat, DocumentStream
from docling.datamodel.pipeline_options import PdfPipelineOptions
from docling.document_converter import DocumentConverter, PdfFormatOption

log = logging.getLogger("vlm_wrapper")
logging.basicConfig(level=logging.INFO)

STUDIO_API_URL = os.environ.get(
    "STUDIO_API_URL",
    "http://comfyuistudio.user-space-admin:3002/api/llm/v1/chat/completions",
)
VLM_MODEL = os.environ.get("VLM_MODEL", "qwen3-vl:8b-instruct-q8_0")
STUDIO_API_KEY = os.environ.get("STUDIO_API_KEY", "")
PDF_TEXT_THRESHOLD = int(os.environ.get("PDF_TEXT_THRESHOLD", "40"))
VLM_SCALE = float(os.environ.get("VLM_SCALE", "2.0"))
VLM_TIMEOUT = int(os.environ.get("VLM_TIMEOUT", "180"))
VLM_PROMPT = os.environ.get(
    "VLM_PROMPT",
    "Transcribe this page to GitHub-flavored Markdown. Preserve all text and "
    "tables exactly. Output only the Markdown, with no commentary.",
)

IMAGE_EXTS = {"png", "jpg", "jpeg", "tif", "tiff", "bmp", "webp", "gif"}


def _strip_md_fence(s: str) -> str:
    """Drop a surrounding ```markdown / ``` code fence some models wrap output in."""
    s = s.strip()
    if s.startswith("```"):
        lines = s.split("\n")
        lines = lines[1:]  # drop opening ``` / ```markdown line
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        s = "\n".join(lines).strip()
    return s

app = FastAPI()
_cpu = None


def cpu_converter():
    global _cpu
    if _cpu is None:
        popt = PdfPipelineOptions(do_ocr=False)  # text-layer only; fast
        _cpu = DocumentConverter(format_options={
            InputFormat.PDF: PdfFormatOption(pipeline_options=popt),
        })
    return _cpu


def pdf_has_text(data: bytes) -> bool:
    """Cheap probe: sample the first few pages' text layer."""
    try:
        pdf = pdfium.PdfDocument(data)
        sample = min(len(pdf), 5)
        total = sum(len(pdf[i].get_textpage().get_text_range().strip())
                    for i in range(sample))
        return (total / max(1, sample)) >= PDF_TEXT_THRESHOLD
    except Exception as e:
        log.warning("pdf text probe failed (%s) → treating as scanned", e)
        return False


def _vlm_png_to_md(png_bytes: bytes) -> str:
    """Send one PNG page to the Studio vision model, return its Markdown."""
    b64 = base64.b64encode(png_bytes).decode()
    headers = {"Content-Type": "application/json"}
    if STUDIO_API_KEY:
        headers["Authorization"] = f"Bearer {STUDIO_API_KEY}"
    payload = {
        "model": VLM_MODEL, "stream": False, "temperature": 0,
        "messages": [{"role": "user", "content": [
            {"type": "text", "text": VLM_PROMPT},
            {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
        ]}],
    }
    r = httpx.post(STUDIO_API_URL, json=payload, headers=headers, timeout=VLM_TIMEOUT)
    r.raise_for_status()
    return _strip_md_fence(r.json()["choices"][0]["message"]["content"] or "")


def vlm_pdf(data: bytes) -> str:
    pdf = pdfium.PdfDocument(data)
    parts = []
    for i in range(len(pdf)):
        pil = pdf[i].render(scale=VLM_SCALE).to_pil().convert("RGB")
        buf = io.BytesIO(); pil.save(buf, format="PNG")
        parts.append(_vlm_png_to_md(buf.getvalue()))
    return "\n\n".join(p for p in parts if p)


def vlm_image(data: bytes) -> str:
    pil = Image.open(io.BytesIO(data)).convert("RGB")
    buf = io.BytesIO(); pil.save(buf, format="PNG")
    return _vlm_png_to_md(buf.getvalue())


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/v1/convert/source")
async def convert(req: Request):
    body = await req.json()
    sources = body.get("sources") or []
    if not sources:
        return JSONResponse({"error": "no sources provided"}, status_code=400)
    src = sources[0]
    filename = src.get("filename", "document")
    try:
        data = base64.b64decode(src.get("base64_string", ""))
    except Exception:
        return JSONResponse({"error": "invalid base64_string"}, status_code=400)

    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in IMAGE_EXTS:
        kind = "image"
    elif ext == "pdf":
        kind = "pdf-text" if pdf_has_text(data) else "pdf-scan"
    else:
        kind = "doc"  # docx/csv/xlsx/pptx/md/html/txt → CPU

    t0 = time.time()
    try:
        if kind == "image":
            md, pipeline = vlm_image(data), "vlm"
        elif kind == "pdf-scan":
            md, pipeline = vlm_pdf(data), "vlm"
        else:  # pdf-text / doc → docling CPU
            res = cpu_converter().convert(
                source=DocumentStream(name=filename, stream=io.BytesIO(data)))
            md, pipeline = res.document.export_to_markdown(), "cpu"
    except httpx.HTTPStatusError as e:
        log.exception("VLM call failed for %s", filename)
        return JSONResponse({"error": f"vlm upstream {e.response.status_code}: "
                             f"{e.response.text[:200]}"}, status_code=502)
    except Exception as e:
        log.exception("convert failed for %s (%s)", filename, kind)
        return JSONResponse({"error": f"convert failed: {e}"}, status_code=502)

    ms = int((time.time() - t0) * 1000)
    log.info("converted %s pipeline=%s ms=%s chars=%s", filename, pipeline, ms, len(md))
    return {
        "document": {"filename": filename, "md_content": md},
        "status": "success",
        "_pipeline": pipeline,
        "_ms": ms,
    }
